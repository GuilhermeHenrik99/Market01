# Sistema de Mercado

Sistema simples em Flask com SQLite para compras e vendas.