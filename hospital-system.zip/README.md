# Sistema Hospitalar

Sistema em Django para cadastro de médicos, pacientes e consultas.